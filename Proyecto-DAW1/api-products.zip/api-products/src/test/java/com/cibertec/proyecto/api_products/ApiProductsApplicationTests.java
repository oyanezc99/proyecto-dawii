package com.cibertec.proyecto.api_products;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiProductsApplicationTests {

	@Test
	void contextLoads() {
	}

}
