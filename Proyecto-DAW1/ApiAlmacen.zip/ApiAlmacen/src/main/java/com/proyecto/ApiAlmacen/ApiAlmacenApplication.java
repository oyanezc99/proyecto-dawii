package com.proyecto.ApiAlmacen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiAlmacenApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiAlmacenApplication.class, args);
	}

}
